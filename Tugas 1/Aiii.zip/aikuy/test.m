A = sim(net, contoh);
nama = {'1', '2', '3', '4', '5', '6'};
mak = 0;

for i=1:6
    if(mak < A(i) * 10)
        mak = i;
    end
end

nama(4)
