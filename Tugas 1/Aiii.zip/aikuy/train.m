b1 = ('number1.jpg');
b2 = ('number2.jpg');
d1 = ('number3.jpg');
d2 = ('number4.jpg');
j1 = ('number5.jpg');
j2 = ('number6.jpg');

% ubah jadi matriks 2 dimensi
ib1 = im2double(imread(b1));
ib2 = im2double(imread(b2));
id1 = im2double(imread(d1));
id2 = im2double(imread(d2));
ij1 = im2double(imread(j1));
ij2 = im2double(imread(j2));

% merubah matriks 2d menjadi 1 baris dengan panjang panjang gambar * lebar
% gambar
r1 = reshape(ib1, 1, 256);
r2 = reshape(ib2, 1, 256);
r3 = reshape(id1, 1, 256);
r4 = reshape(id2, 1, 256);
r5 = reshape(ij1, 1, 256);
r6 = reshape(ij2, 1, 256);

% transpose matriks notasinya adalah`r1'`
k1 = r1';
k2 = r2';
k3 = r3';
k4 = r4';
k5 = r5';
k6 = r6';

citra_training = [k1 k2 k3 k4 k5 k6];
target = eye(6);

[R, Q] = size(citra_training);
[S2, Q] = size(target);

S1=10;
net = newff(minmax(citra_training), [S1 S2], {'logsig', 'logsig'}, 'traingdx');
net.LW{2, 1} = net.LW{2, 1} * 0.01;
net.b{2} = net.b{2} * 0.01;

net.performFcn = 'sse';
net.trainParam.goal = 0.01;
net.trainParam.show = 20;
net.trainParam.epochs = 5000;
net.trainParam.mc = 0.95;

P = citra_training;
T = target;

[net, tr] = train(net, P, T);