function varargout = try_gui(varargin)
% TRY_GUI MATLAB code for try_gui.fig
%      TRY_GUI, by itself, creates a new TRY_GUI or raises the existing
%      singleton*.
%
%      H = TRY_GUI returns the handle to a new TRY_GUI or the handle to
%      the existing singleton*.
%
%      TRY_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TRY_GUI.M with the given input arguments.
%
%      TRY_GUI('Property','Value',...) creates a new TRY_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before try_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to try_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help try_gui

% Last Modified by GUIDE v2.5 27-May-2018 22:42:50

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @try_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @try_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before try_gui is made visible.
function try_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to try_gui (see VARARGIN)

% Choose default command line output for try_gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes try_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = try_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in btnCapture.
function btnCapture_Callback(hObject, eventdata, handles)
% hObject    handle to btnCapture (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
savepath = 'E:\UNPAD\TeknikInformatika\public\kuliah\SMST4\AI\project_uas\aikuy';
cam=webcam(1);
preview(cam);
for idx = 1:60
   img = snapshot(cam);
   image(img);
    gray = rgb2gray(img);
end
fullname=fullfile(savepath,'namafile.jpg');
imwrite(gray,fullname);
I=imread('namafile.jpg');
imThresh = graythresh(I);
BW=im2bw(I,imThresh);
J=imcomplement(imresize(BW,[16 16]));
fullname2=fullfile(savepath,'namafile2.jpg');
imwrite(J,fullname2);
imshowpair(I, BW,'montage');

% --- Executes on button press in btnProcess.
function btnProcess_Callback(hObject, eventdata, handles)
% hObject    handle to btnProcess (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
b1 = ('number1.jpg');
% b2 = ('number2.jpg');
% d1 = ('number3.jpg');
% d2 = ('number4.jpg');
% j1 = ('number5.jpg');
% j2 = ('number6.jpg');

% % ubah jadi matriks 2 dimensi
% ib1 = im2double(imread(b1));
% ib2 = im2double(imread(b2));
% id1 = im2double(imread(d1));
% id2 = im2double(imread(d2));
% ij1 = im2double(imread(j1));
% ij2 = im2double(imread(j2));

% % merubah matriks 2d menjadi 1 baris dengan panjang panjang gambar * lebar
% % gambar
% r1 = reshape(ib1, 1, 256);
% r2 = reshape(ib2, 1, 256);
% r3 = reshape(id1, 1, 256);
% r4 = reshape(id2, 1, 256);
% r5 = reshape(ij1, 1, 256);
% r6 = reshape(ij2, 1, 256);

% % transpose matriks notasinya adalah`r1'`
% k1 = r1';
% k2 = r2';
% k3 = r3';
% k4 = r4';
% k5 = r5';
% k6 = r6';

% citra_training = [k1 k2 k3 k4 k5 k6];
% target = eye(6);

% [R, Q] = size(citra_training);
% [S2, Q] = size(target);

% S1=10;
% net = newff(minmax(citra_training), [S1 S2], {'logsig', 'logsig'}, 'traingdx');
% net.LW{2, 1} = net.LW{2, 1} * 0.01;
% net.b{2} = net.b{2} * 0.01;

% net.performFcn = 'sse';
% net.trainParam.goal = 0.01;
% net.trainParam.show = 20;
% net.trainParam.epochs = 5000;
% net.trainParam.mc = 0.95;

% P = citra_training;
% T = target;

% [net, tr] = train(net, P, T);
% a = im2double(imread('namafile2.jpg'));
% b = reshape(a,1,256);
% c = b';
% contoh = c;
load('train.mat');
a = im2double(imread('namafile2.jpg'));
b = reshape(a,1,256);
c = b';
contoh = c;
A = sim(net, contoh);
nama = {'1', '2', '3', '4', '5', '6'};
mak = 0;

for i=1:6
    if(mak < A(i) * 10)
        mak = i;
    end
end

nama(mak)
